﻿using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using YouTubeTestApp.BaseClass;
using YouTubeTestApp.PageObjects;

namespace YouTubeTestApp.TestScripts
{
    [TestFixture]
    public class Module1:BaseTest
    {
        [Test]
        public void TestMethod1()
        {
            //driver.FindElement(By.Id("search")).SendKeys("ASP.NEt Core");
            //driver.FindElement(By.CssSelector("#search-icon-legacy")).Click();
            var searchPage = new SearchPage(driver);
            var resultPage = searchPage.NavigateToResult();
            var chanelPage = resultPage.NavigateToChanel();

            string actualChanelName = chanelPage.getChannelName();
            string expectedChanelname = "Tutorialspoint";

            Assert.IsTrue(actualChanelName.Equals(expectedChanelname));
            //var searchPage = new SearchPage();
            //PageFactory.InitElements(driver, searchPage);
            //searchPage.SearchTextBox.SendKeys("Asp.NET Core");
            //searchPage.SearchButton.Click();
            
            Thread.Sleep(3000);
        }
    }
}
