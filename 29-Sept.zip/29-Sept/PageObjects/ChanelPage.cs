﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YouTubeTestApp.PageObjects
{
  public class ChanelPage
    {
        IWebDriver driver;
        public ChanelPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How=How.CssSelector,Using =("#logo-menu > div > div.left-menu > a"))]
        public IWebElement ChannelName { get; set; }

        public string getChannelName()
        {
            return ChannelName.GetAttribute("title");
        }
    }
}
