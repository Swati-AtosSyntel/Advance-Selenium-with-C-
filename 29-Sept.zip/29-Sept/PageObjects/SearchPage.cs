﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace YouTubeTestApp.PageObjects
{
  public  class SearchPage
    {
        IWebDriver driver;
        public SearchPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }
        [FindsBy(How=How.Name,Using="q")]
        public IWebElement SearchTextBox { get; set; }

        [FindsBy(How=How.Name,Using = "btnK")]
        public IWebElement SearchButton { get; set; }

        public ResultPage NavigateToResult()
        {
             //Thread.Sleep(2000);
            SearchTextBox.SendKeys("Asp.NETCore");
            Thread.Sleep(2000);
            SearchButton.Click();
            Thread.Sleep(2000);
            return new ResultPage(driver);
        }
    }
}
