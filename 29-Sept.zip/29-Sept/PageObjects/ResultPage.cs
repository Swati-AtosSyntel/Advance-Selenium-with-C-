﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace YouTubeTestApp.PageObjects
{
   public class ResultPage
    {
        IWebDriver driver;
        public ResultPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How=How.PartialLinkText,Using = "Tutorialspoint")]
        public IWebElement ChanelNameLinkText { get; set; }

        public ChanelPage NavigateToChanel()
        {
            Thread.Sleep(5000);
            ChanelNameLinkText.Click();
            return new ChanelPage(driver);
        }
    }
}
