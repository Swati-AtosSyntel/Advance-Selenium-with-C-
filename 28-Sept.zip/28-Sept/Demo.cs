﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace ConsoleApp28Sept
{
    class Demo
    {
        IWebDriver driver;
        [SetUp]
        public void Open()
        {
            driver = new ChromeDriver();
            //driver.Url=("file:///C:/Swati/2020/Manufacturing/September-2020-ODesktop/Advance%20Selenium%20with%20C%23/ConsoleApp28Sept/ConsoleApp28Sept/index.html");
            driver.Url = "https://www.demoqa.com/browser-windows";
            driver.Manage().Window.Maximize();

            Thread.Sleep(2000);
        }
        //[Test]
        public void ConfirmationAlertExample()
        {
            driver.FindElement(By.Name("cusid")).SendKeys("53920");
            driver.Manage().Timeouts().ImplicitWait=TimeSpan.FromSeconds(30);
            //Thread.Sleep(2000);
            driver.FindElement(By.Name("submit")).Click();
            Thread.Sleep(4000);
            IAlert alert = driver.SwitchTo().Alert();
            string msg = alert.Text;
            Console.WriteLine(msg);
            Thread.Sleep(4000);
            alert.Accept();
            Thread.Sleep(6000);
        }
        [Test]
        public void HandleMultipleWindows()
        {
            string mainWindow = driver.CurrentWindowHandle;
            for(int i=0;i<3;i++)
            {
                driver.FindElement(By.Id("windowButton")).Click();
                Thread.Sleep(2000);
                 Console.WriteLine(driver.Url);
            }
            //driver.FindElement(By.PartialLinkText("Click Here")).Click();
            //Thread.Sleep(2000);
            //driver.SwitchTo().Window(mainWindow);
            //Thread.Sleep(2000);
            //driver.FindElement(By.PartialLinkText("Calculator")).Click();
            //Thread.Sleep(2000);
            IList<string> windows = driver.WindowHandles.ToList();

            foreach(var handle in windows)
                Console.WriteLine(handle);
            driver.SwitchTo().Window(mainWindow);
            Thread.Sleep(2000);

        }
        [TearDown]
        public void Close()
        {
            //driver.Close();
        }

    }
}
